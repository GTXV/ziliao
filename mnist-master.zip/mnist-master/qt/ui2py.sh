#!/bin/bash
pyuic5 -o layout.py layout.ui
